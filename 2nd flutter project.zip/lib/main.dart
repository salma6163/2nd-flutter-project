import 'dart:html';

import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Application name
      home: Scaffold(
        appBar: AppBar(
          title: Text("2nd flutter task"),
        ),
        body: Column(
          children: [
            Center(
              child: Text(
                "Create Account",
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Text(
              " Please fill the input below here ",
              style: TextStyle(
                fontSize: 15,
                color: Color(0xffcba9a9),
                //fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(
              height: 40,
            ),

            TextFormField(
              showCursor: true,
              //initialValue: " Email  ",
              obscureText: false, //start text which can remove
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(width: 2, color: Colors.black),
                ),
                labelText: "Full Name",
                hintText: "enter your name", //write on it not remove or delete
                icon: Icon(Icons.person),
              ),
            ),

            SizedBox(
              height: 40,
            ),

            TextFormField(
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(width: 2, color: Colors.black),
                  borderRadius: BorderRadius.circular(10),
                ),
                labelText: "Phone",
                hintText: "enter your phone number",
                icon: Icon(Icons.phone_android),
              ),
              showCursor: false,
              // initialValue: " 000 ",
              initialValue: " +20  ",
              obscureText: false,
            ),

            SizedBox(
              height: 40,
            ),

            TextFormField(
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(width: 2, color: Colors.black),
                  borderRadius: BorderRadius.circular(10),
                ),
                labelText: "Email",
                hintText: "enter your email",
                icon: Icon(Icons.email),
              ),
              showCursor: true,
              // initialValue: "  +20 ",
              obscureText: false,
            ),

            SizedBox(
              height: 40,
            ),

            TextFormField(
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(width: 2, color: Colors.black),
                  borderRadius: BorderRadius.circular(10),
                ),
                labelText: "Password",
                hintText: "enter your pass",
                icon: Icon(Icons.lock),
              ),
              showCursor: true,
              //initialValue: "  +20 ",
              obscureText: false,
            ),

            SizedBox(
              height: 40,
            ),

            TextFormField(
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(width: 2, color: Colors.black),
                  borderRadius: BorderRadius.circular(10),
                ),
                labelText: "Confirm password",
                hintText: "confirm your oass",
                icon: Icon(Icons.lock),
              ),
              showCursor: true,
              // initialValue: "  ",
              obscureText: false,
            ),
            //user can write data
          ],
        ),
      ),
    );
  }
}
